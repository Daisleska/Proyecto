CREATE DATABASE IF NOT EXISTS `servidata`;

USE `servidata`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `almacen`;

CREATE TABLE `almacen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_producto` int(11) NOT NULL,
  `id_ubicacion` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `ce` varchar(90) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paletas` varchar(90) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_producto` (`id_producto`),
  KEY `id_ubicacion` (`id_ubicacion`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `almacen` VALUES (1,1,1,11,NULL,NULL);


DROP TABLE IF EXISTS `asignacion_deduccion`;

CREATE TABLE `asignacion_deduccion` (
  `id` int(90) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `tipo` enum('Asignacion','Deduccion') COLLATE utf8_unicode_ci NOT NULL,
  `monto` int(90) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_tipo` (`tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `asignacion_deduccion` VALUES (1,"Memoriales La Victoria C.A","Deduccion",15000),
(2,"Prima por Hijo","Asignacion",50000);


DROP TABLE IF EXISTS `asistencias`;

CREATE TABLE `asistencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) NOT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'fecha de asistencia',
  `status` enum('A','NACJ','NASJ','Sin Marcar') COLLATE utf8_unicode_ci NOT NULL,
  `justificacion` enum('Permiso','Reposo','','') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rest_asis` (`id_empleado`),
  CONSTRAINT `rest_asis` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `auditoria`;

CREATE TABLE `auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `actividad` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `status` enum('0','1') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `cargos`;

CREATE TABLE `cargos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `salario` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `id_departamento` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_departamentos` (`id_departamento`),
  CONSTRAINT `rest_departamento` FOREIGN KEY (`id_departamento`) REFERENCES `departamentos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cargos` VALUES (1,"Jefe",1000000,1),
(2,"Asistente",400000,2);


DROP TABLE IF EXISTS `cestaticket`;

CREATE TABLE `cestaticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `monto` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cestaticket` VALUES (1,25000);


DROP TABLE IF EXISTS `departamentos`;

CREATE TABLE `departamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `departamentos` VALUES (1,"Almacen"),
(2,"Recursos Humanos"),
(3,"Administración"),
(4,"Informática"),
(5,"Producción");


DROP TABLE IF EXISTS `despachos`;

CREATE TABLE `despachos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_almacen` int(11) NOT NULL,
  `cantidad` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `paletas` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `observacion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `destino` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `dia_lab`;

CREATE TABLE `dia_lab` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rest_dia` (`id_empleado`),
  CONSTRAINT `rest_dia` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `dia_lab` VALUES (31,1," Lunes"),
(32,1," Martes"),
(33,1," MiÃ©rcoles"),
(34,1," Jueves"),
(35,1," Viernes"),
(36,1," SÃ¡bado"),
(37,1," Domingo"),
(41,2," Lunes"),
(42,2," Martes"),
(43,2," MiÃ©rcoles"),
(44,3," Martes"),
(45,3," MiÃ©rcoles"),
(46,3," Jueves");


DROP TABLE IF EXISTS `empleado`;

CREATE TABLE `empleado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `nombres` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `apellidos` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `condicion` enum('Fijo','Contratado') COLLATE utf8_unicode_ci NOT NULL,
  `fecha_venc` date NOT NULL,
  `ncuenta` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `id_cargo` int(11) NOT NULL,
  `id_departamento` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cargo` (`id_cargo`),
  CONSTRAINT `rest_cargo` FOREIGN KEY (`id_cargo`) REFERENCES `cargos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `empleado` VALUES (1,25873122,"Juan Carlos","Figueredo ","La Victoria",04243160235,"2019-10-08","Fijo","2024-10-18",01354567898765432345,2,2),
(2,28147989,"Hector Argenis","Hernandez Ceballo","San Mateo",04243590130,"2019-10-09","Contratado","2019-11-06",01915678890998787654,1,2),
(3,18610668,"Eynsterd Samuel","Velazco","Zuata",04163462604,"2019-10-08","Fijo","2019-10-30",01027693406500432765,2,3);


DROP TABLE IF EXISTS `empleado_asig`;

CREATE TABLE `empleado_asig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) NOT NULL,
  `id_asignaciones` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `empl` (`id_empleado`),
  KEY `asig` (`id_asignaciones`),
  CONSTRAINT `asig` FOREIGN KEY (`id_asignaciones`) REFERENCES `asignacion_deduccion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `empl` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `empleado_asig` VALUES (1,1,2),
(2,1,1),
(3,2,1),
(4,2,2),
(5,3,1),
(6,3,2);


DROP TABLE IF EXISTS `empleado_pago`;

CREATE TABLE `empleado_pago` (
  `id_empleado` int(11) NOT NULL,
  `id_pago` int(11) NOT NULL,
  `horas_justificadas` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `horas_sobre_t` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  KEY `ci_e` (`id_empleado`),
  KEY `id_pago` (`id_pago`),
  CONSTRAINT `empleado_pago_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `empleado_pago_ibfk_2` FOREIGN KEY (`id_pago`) REFERENCES `pago` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `empleado_producto`;

CREATE TABLE `empleado_producto` (
  `id_empleado` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `linea_produccion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  KEY `ci_e` (`id_empleado`),
  KEY `cod_p` (`id_producto`),
  CONSTRAINT `empleado_producto_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rest_emp` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `enviados`;

CREATE TABLE `enviados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_productos` int(11) NOT NULL,
  `id_ubicacion` int(11) NOT NULL,
  `id_codigo` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_registro` date NOT NULL,
  `observacion` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ubicacion` (`id_ubicacion`),
  KEY `id_codigo` (`id_codigo`),
  KEY `id_productos` (`id_productos`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `enviados` VALUES (1,0,2,0,100,"2019-11-06",NULL),
(2,0,2,0,100,"2019-11-06",NULL),
(3,0,2,0,40,"2019-11-06",NULL),
(4,0,2,0,1000,"2019-11-06",NULL),
(5,0,2,0,100,"2019-11-06",NULL),
(6,0,2,0,10,"2019-11-06",NULL);


DROP TABLE IF EXISTS `historial`;

CREATE TABLE `historial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tiempo` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `motivo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_producto` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `historial` VALUES (1,"2019-11-05 21:42:52","ingreso",1,100),
(2,"2019-11-05 21:46:05","egreso",5,-10),
(3,"2019-11-05 21:50:20","ingreso",5,100);


DROP TABLE IF EXISTS `inventario`;

CREATE TABLE `inventario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_productos` int(11) NOT NULL,
  `estado` enum('aceptado','rechazado') COLLATE utf8_unicode_ci NOT NULL,
  `observaciones` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_entrega` date NOT NULL,
  `fecha_vencimiento` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `inventario_producto` (`id_productos`),
  CONSTRAINT `inventario_producto` FOREIGN KEY (`id_productos`) REFERENCES `productos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `inventario` VALUES (1,1,"aceptado","ninguna",160,"2019-09-06","2019-09-30"),
(6,2,"aceptado","ninguno",440,"2019-10-08","0000-00-00");


DROP TABLE IF EXISTS `materia_prima`;

CREATE TABLE `materia_prima` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `presentacion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `unidad` enum('Kgs','Lts') COLLATE utf8_unicode_ci NOT NULL,
  `stock` int(11) NOT NULL,
  `stock_minimo` int(11) NOT NULL,
  `stock_maximo` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `borrado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `activo` enum('S','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `materia_prima` VALUES (1,"C1903","XILENO ","BARITANQUE DE 1000 LTS ","Lts",5050,1000,100000,"N","S"),
(2,"2h2h22","madera","tablas","Lts",30,10,40,"N","S"),
(3,"2h2fkfk","agua","paletas","Lts",2000,100,10000,"N","S");


DROP TABLE IF EXISTS `materiaprima_producto`;

CREATE TABLE `materiaprima_producto` (
  `id_materiaprima` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad_u_mp` int(90) NOT NULL,
  `cantidad_exist_mp` int(90) NOT NULL,
  KEY `cod_mp` (`id_materiaprima`),
  KEY `cod_p` (`id_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `materiaprima_proveedor`;

CREATE TABLE `materiaprima_proveedor` (
  `id_materiaprima` int(11) NOT NULL,
  `id_proveedor` int(11) NOT NULL,
  `cantidad_c_mp` int(90) NOT NULL,
  `cantidad_exist_mp` int(90) NOT NULL,
  KEY `cod_mp` (`id_materiaprima`),
  KEY `ci_pro` (`id_proveedor`),
  CONSTRAINT `materiaprima_proveedor_ibfk_2` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `nomina`;

CREATE TABLE `nomina` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) NOT NULL,
  `id_prenomina` int(11) NOT NULL,
  `sueldo` varchar(90) NOT NULL,
  `total_asig` varchar(90) NOT NULL,
  `total_deducc` varchar(90) NOT NULL,
  `monto` varchar(90) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_empleado` (`id_empleado`),
  KEY `id_prenomina` (`id_prenomina`),
  CONSTRAINT `nomina_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `nomina_ibfk_2` FOREIGN KEY (`id_prenomina`) REFERENCES `pre_nomina` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `pago`;

CREATE TABLE `pago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sueldo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `monto` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `periodo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `pago_ibfk_1` FOREIGN KEY (`id`) REFERENCES `pago_asignaciondeduccion` (`id_pago`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `pago_asignaciondeduccion`;

CREATE TABLE `pago_asignaciondeduccion` (
  `id_pago` int(90) NOT NULL,
  `id_ad` int(90) NOT NULL,
  KEY `id_pago` (`id_pago`),
  KEY `id_ad` (`id_ad`),
  CONSTRAINT `pago_asignaciondeduccion_ibfk_1` FOREIGN KEY (`id_ad`) REFERENCES `asignacion_deduccion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `permisos`;

CREATE TABLE `permisos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `motivo` enum('Reposo','Permiso') COLLATE utf8_unicode_ci DEFAULT NULL,
  `cantidad_dias` int(11) NOT NULL,
  `inicio_permiso` date NOT NULL,
  `fin_permiso` date NOT NULL,
  `resta` int(11) NOT NULL,
  `status` enum('En Curso','Cumplido') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'En Curso',
  `id_empleado` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `dias_permiso` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `permisos` VALUES (1,"Reposo",3,"2019-10-01","2019-10-03",3,"En Curso",3),
(2,"Permiso",3,"2019-10-20","2019-10-22",3,"En Curso",3);


DROP TABLE IF EXISTS `pre_nomina`;

CREATE TABLE `pre_nomina` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quincena` int(90) NOT NULL,
  `mes` int(90) NOT NULL,
  `anio` int(90) NOT NULL,
  `status` enum('Procesando','Aprobado') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `pre_nomina` VALUES (3,1,10,2019,"Procesando");


DROP TABLE IF EXISTS `prenomina_empleado`;

CREATE TABLE `prenomina_empleado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_prenomina` int(11) NOT NULL,
  `id_empleado` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_prenomina` (`id_prenomina`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `prenomina_empleado_ibfk_1` FOREIGN KEY (`id_prenomina`) REFERENCES `pre_nomina` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `prenomina_empleado_ibfk_2` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `prenomina_empleado` VALUES (7,3,1),
(8,3,2),
(9,3,3);


DROP TABLE IF EXISTS `privilegios`;

CREATE TABLE `privilegios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `modulo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `privilegio` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `privilegios` VALUES (1,"proveedor","registrar"),
(2,"proveedor","listado"),
(3,"proveedor","modificar"),
(4,"proveedor","eliminar"),
(5,"materiaprima","registrar"),
(6,"materiaprima","listado"),
(7,"materiaprima","modificar"),
(8,"materiaprima","eliminar"),
(9,"inventario","registrar"),
(10,"inventario","listado"),
(11,"inventario","modificar"),
(12,"inventario","eliminar"),
(13,"empleado","registrar"),
(14,"empleado","listado"),
(15,"empleado","modificar"),
(16,"empleado","eliminar"),
(17,"asistencia","registrar"),
(18,"asistencia","listado"),
(19,"asistencia","modificar"),
(20,"asistencia","eliminar"),
(21,"asigdeducc","registrar"),
(22,"asigdeducc","listado"),
(23,"asigdeducc","modificar"),
(24,"asigdeducc","eliminar"),
(25,"nomina","registrar"),
(26,"nomina","listado"),
(27,"nomina","modificar"),
(28,"nomina","eliminar"),
(32,"mantenimiento","bitacora"),
(33,"mantenimiento","respaldo"),
(34,"mantenimiento","recuperacion"),
(35,"mantenimiento","listado");


DROP TABLE IF EXISTS `produccion`;

CREATE TABLE `produccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_producto` int(11) NOT NULL,
  `cantidad` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `paletas` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `observacion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `status` enum('Sin Almacenar','Almacenando','Completo') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `producto_proveedor`;

CREATE TABLE `producto_proveedor` (
  `id` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `id_proveedor` int(11) NOT NULL,
  `cantidad_d_p` int(90) NOT NULL,
  `cantidad_exist_p` int(90) NOT NULL,
  KEY `cod_p` (`id_producto`),
  KEY `ci_pro` (`id_proveedor`),
  CONSTRAINT `producto_proveedor_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `productos`;

CREATE TABLE `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `presentacion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `unidad` enum('Kgs','Lts') COLLATE utf8_unicode_ci NOT NULL,
  `stock` int(11) NOT NULL,
  `stock_minimo` int(11) NOT NULL,
  `stock_maximo` int(11) NOT NULL,
  `borrado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `activo` enum('S','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `productos` VALUES (1,12356,"hierro","paletas","Kgs",10,5,30,"N","S"),
(2,7272727,"metal","paletas","Lts",80,10,5000,"N","S"),
(3,"nuh779","cosa","paletas","Kgs",10,10,200,"N","S"),
(4,32020,"madera","flota","Lts",56,10,100,"N","N"),
(5,"2h2h22","koll","tablas","Lts",869,9,900,"N","S");


DROP TABLE IF EXISTS `proveedor`;

CREATE TABLE `proveedor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cod_rif` enum('V','J','E','G') COLLATE utf8_unicode_ci NOT NULL,
  `cedula` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `borrado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `proveedor` VALUES (2,"V",25873122,"Juan Carlos Figueredo","juan2912@gmail.com","La Victoria",3163502,"N"),
(4,"J","J-1345678","Inica Cagua C.A","inicacca@gmail.com","Cagua ",9876556,"S"),
(5,"V",29554496,"holahhh","holgggggga@gmail.com","aahha",23456787654,"N"),
(6,"V",23353454,"esaaaaaa","","gagu",342342323,"N"),
(7,"V",099988,"koll","hectorher149@gmail.com","",8889998,"S");


DROP TABLE IF EXISTS `recibidos`;

CREATE TABLE `recibidos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pmp` int(11) NOT NULL,
  `cantidad` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `observacion` varchar(90) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ce` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `recibidos` VALUES (2,1,102002,"2019-10-07","8jjkk","");


DROP TABLE IF EXISTS `ubicacion`;

CREATE TABLE `ubicacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `bloqueado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `borrado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tipo` enum('I','E') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `ubicacion` VALUES (1,"produccion","N","N","I"),
(2,"almacen","N","N","I");


DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `correo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `clave` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_usuario` enum('Admin','Usuario 1','Usuario 2') COLLATE utf8_unicode_ci NOT NULL,
  `pregunta` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `respuesta` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `borrado` enum('S','N') COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `usuarios` VALUES (1,"Daileska Vilera","dvilera610@gmail.com","044598473886535a33126083e3d2e1170e4a67befe897a83ad95a33209a64b3a","Usuario 1","Mascota","Sandy","S"),
(2,"hector hernandez","hectorher149@gmail.com","53c6dd220f272d3e88bb3b404d32ff65af6f749ee94c90405fd7a15819bbcf40","Usuario 1","nombre de mascota","body","N"),
(3,"Alejandro","darvisalfonso@gmail.com","67d9f1c944a4ee6ef3634298c97639c81927a228d6aa490b343abf594e45aecf","Usuario 1","nombre de mascota","pelusa","S"),
(4,"Genessi","genessie@gmail.com","8491502322172e09ec7222d33941d33afbfcc22ab0c4dd1033dd72232308675a","Admin","mes de nacimiento","noviembre","S");


DROP TABLE IF EXISTS `usuarios_has_privilegios`;

CREATE TABLE `usuarios_has_privilegios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_privilegio` int(11) NOT NULL,
  `status` enum('Si','No') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_privilegio` (`id_privilegio`),
  CONSTRAINT `usuarios_has_privilegios_ibfk_1` FOREIGN KEY (`id_privilegio`) REFERENCES `privilegios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `usuarios_has_privilegios_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `usuarios_has_privilegios` VALUES (1,1,1,"No"),
(2,1,2,"No"),
(3,1,3,"No"),
(4,1,4,"No"),
(5,1,5,"No"),
(6,1,6,"No"),
(7,1,7,"No"),
(8,1,8,"No"),
(9,1,9,"No"),
(10,1,10,"No"),
(11,1,11,"No"),
(12,1,12,"No"),
(13,1,13,"No"),
(14,1,14,"No"),
(15,1,15,"No"),
(16,1,16,"No"),
(17,1,17,"No"),
(18,1,18,"No"),
(19,2,1,"No"),
(20,2,2,"No"),
(21,2,3,"No"),
(22,2,4,"No"),
(23,2,5,"No"),
(24,2,6,"No"),
(25,2,7,"No"),
(26,2,8,"No"),
(27,2,9,"No"),
(28,2,10,"No"),
(29,2,11,"No"),
(30,2,12,"No"),
(31,2,13,"No"),
(32,2,14,"No"),
(33,2,15,"No"),
(34,2,16,"No"),
(35,2,17,"No"),
(36,2,18,"No"),
(37,3,1,"No"),
(38,3,2,"No"),
(39,3,3,"No"),
(40,3,4,"No"),
(41,3,5,"No"),
(42,3,6,"No"),
(43,3,7,"No"),
(44,3,8,"No"),
(45,3,9,"No"),
(46,3,10,"No"),
(47,3,11,"No"),
(48,3,12,"No"),
(49,3,13,"No"),
(50,3,14,"No"),
(51,3,15,"No"),
(52,3,16,"No"),
(53,3,17,"No"),
(54,3,18,"No"),
(55,4,1,"No"),
(56,4,2,"No"),
(57,4,3,"No"),
(58,4,4,"No"),
(59,4,5,"No"),
(60,4,6,"No"),
(61,4,7,"No"),
(62,4,8,"No"),
(63,4,9,"No"),
(64,4,10,"No"),
(65,4,11,"No"),
(66,4,12,"No"),
(67,4,13,"No"),
(68,4,14,"No"),
(69,4,15,"No"),
(70,4,16,"No"),
(71,4,17,"No"),
(72,4,18,"No");


SET foreign_key_checks = 1;
