CREATE DATABASE IF NOT EXISTS `servidata`;

USE servidata;

DROP TABLE IF EXISTS `almacen`;

CREATE TABLE `almacen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_producto` int(11) NOT NULL,
  `id_ubicacion` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `ce` varchar(90) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paletas` varchar(90) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_producto` (`id_producto`),
  KEY `id_ubicacion` (`id_ubicacion`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `almacen` VALUES("1","1","1","11",NULL,NULL);



DROP TABLE IF EXISTS `asignacion_deduccion`;

CREATE TABLE `asignacion_deduccion` (
  `id` int(90) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `tipo` enum('Asignacion','Deduccion') COLLATE utf8_unicode_ci NOT NULL,
  `monto` int(90) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_tipo` (`tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `asignacion_deduccion` VALUES("1","Memoriales La Victoria C.A","Deduccion","15000");
INSERT INTO `asignacion_deduccion` VALUES("2","Prima por Hijo","Asignacion","50000");
INSERT INTO `asignacion_deduccion` VALUES("3","prima hijo","Asignacion","12000");



DROP TABLE IF EXISTS `asistencias`;

CREATE TABLE `asistencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) NOT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'fecha de asistencia',
  `status` enum('A','NACJ','NASJ','Sin Marcar') COLLATE utf8_unicode_ci NOT NULL,
  `justificacion` enum('Permiso','Reposo','','') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rest_asis` (`id_empleado`),
  CONSTRAINT `rest_asis` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `asistencias` VALUES("4","1","2019-11-13 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("5","3","2019-11-13 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("6","1","2019-11-15 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("7","1","2019-11-16 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("8","1","2019-11-21 00:00:00","A","");
INSERT INTO `asistencias` VALUES("9","3","2019-11-21 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("10","1","2019-11-22 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("11","1","2019-11-27 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("12","2","2019-11-27 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("13","3","2019-11-27 00:00:00","Sin Marcar","");



DROP TABLE IF EXISTS `auditoria`;

CREATE TABLE `auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `actividad` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `status` enum('0','1') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `cargos`;

CREATE TABLE `cargos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `salario` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `id_departamento` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_departamentos` (`id_departamento`),
  CONSTRAINT `rest_departamento` FOREIGN KEY (`id_departamento`) REFERENCES `departamentos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cargos` VALUES("1","Jefe","1000000","1");
INSERT INTO `cargos` VALUES("2","Asistente","400000","2");



DROP TABLE IF EXISTS `cestaticket`;

CREATE TABLE `cestaticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `monto` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cestaticket` VALUES("1","25000");



DROP TABLE IF EXISTS `departamentos`;

CREATE TABLE `departamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `departamentos` VALUES("1","Almacen");
INSERT INTO `departamentos` VALUES("2","Recursos Humanos");
INSERT INTO `departamentos` VALUES("3","Administración");
INSERT INTO `departamentos` VALUES("4","Informática");
INSERT INTO `departamentos` VALUES("5","Producción");



DROP TABLE IF EXISTS `despachos`;

CREATE TABLE `despachos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_almacen` int(11) NOT NULL,
  `cantidad` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `paletas` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `observacion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `destino` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `dia_lab`;

CREATE TABLE `dia_lab` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rest_dia` (`id_empleado`),
  CONSTRAINT `rest_dia` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `dia_lab` VALUES("31","1"," Lunes");
INSERT INTO `dia_lab` VALUES("32","1"," Martes");
INSERT INTO `dia_lab` VALUES("33","1"," MiÃ©rcoles");
INSERT INTO `dia_lab` VALUES("34","1"," Jueves");
INSERT INTO `dia_lab` VALUES("35","1"," Viernes");
INSERT INTO `dia_lab` VALUES("36","1"," SÃ¡bado");
INSERT INTO `dia_lab` VALUES("37","1"," Domingo");
INSERT INTO `dia_lab` VALUES("41","2"," Lunes");
INSERT INTO `dia_lab` VALUES("42","2"," Martes");
INSERT INTO `dia_lab` VALUES("43","2"," MiÃ©rcoles");
INSERT INTO `dia_lab` VALUES("44","3"," Martes");
INSERT INTO `dia_lab` VALUES("45","3"," MiÃ©rcoles");
INSERT INTO `dia_lab` VALUES("46","3"," Jueves");



DROP TABLE IF EXISTS `empleado`;

CREATE TABLE `empleado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `nombres` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `apellidos` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `condicion` enum('Fijo','Contratado') COLLATE utf8_unicode_ci NOT NULL,
  `fecha_venc` date NOT NULL,
  `ncuenta` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `id_cargo` int(11) NOT NULL,
  `id_departamento` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cargo` (`id_cargo`),
  CONSTRAINT `rest_cargo` FOREIGN KEY (`id_cargo`) REFERENCES `cargos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `empleado` VALUES("1","25873122","Juan Carlos","Figueredo ","La Victoria","04243160235","2019-10-08","Fijo","2024-10-18","01354567898765432345","2","2");
INSERT INTO `empleado` VALUES("2","28147989","Hector Argenis","Hernandez Ceballo","San Mateo","04243590130","2019-10-09","Contratado","2019-11-06","01915678890998787654","1","2");
INSERT INTO `empleado` VALUES("3","18610668","Eynsterd Samuel","Velazco","Zuata","04163462604","2019-10-08","Fijo","2019-10-30","01027693406500432765","2","3");



DROP TABLE IF EXISTS `empleado_asig`;

CREATE TABLE `empleado_asig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) NOT NULL,
  `id_asignaciones` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `empl` (`id_empleado`),
  KEY `asig` (`id_asignaciones`),
  CONSTRAINT `asig` FOREIGN KEY (`id_asignaciones`) REFERENCES `asignacion_deduccion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `empl` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `empleado_asig` VALUES("1","1","2");
INSERT INTO `empleado_asig` VALUES("2","1","1");
INSERT INTO `empleado_asig` VALUES("3","2","1");
INSERT INTO `empleado_asig` VALUES("4","2","2");
INSERT INTO `empleado_asig` VALUES("5","3","1");
INSERT INTO `empleado_asig` VALUES("6","3","2");



DROP TABLE IF EXISTS `empleado_pago`;

CREATE TABLE `empleado_pago` (
  `id_empleado` int(11) NOT NULL,
  `id_pago` int(11) NOT NULL,
  `horas_justificadas` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `horas_sobre_t` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  KEY `ci_e` (`id_empleado`),
  KEY `id_pago` (`id_pago`),
  CONSTRAINT `empleado_pago_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `empleado_pago_ibfk_2` FOREIGN KEY (`id_pago`) REFERENCES `pago` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `empleado_producto`;

CREATE TABLE `empleado_producto` (
  `id_empleado` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `linea_produccion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  KEY `ci_e` (`id_empleado`),
  KEY `cod_p` (`id_producto`),
  CONSTRAINT `empleado_producto_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rest_emp` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `enviados`;

CREATE TABLE `enviados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_productos` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `id_ubicacion` int(11) NOT NULL,
  `id_codigo` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_registro` date NOT NULL,
  `observacion` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ubicacion` (`id_ubicacion`),
  KEY `id_codigo` (`id_codigo`),
  KEY `id_productos` (`id_productos`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `enviados` VALUES("1","0","2","0","100","2019-11-06",NULL);
INSERT INTO `enviados` VALUES("2","0","2","0","100","2019-11-06",NULL);
INSERT INTO `enviados` VALUES("3","0","2","0","40","2019-11-06",NULL);
INSERT INTO `enviados` VALUES("4","0","2","0","1000","2019-11-06",NULL);
INSERT INTO `enviados` VALUES("5","0","2","0","100","2019-11-06",NULL);
INSERT INTO `enviados` VALUES("6","0","2","0","10","2019-11-06",NULL);
INSERT INTO `enviados` VALUES("7","0","1","0","50","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("8","0","2","0","50","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("9","0","1","0","100","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("10","0","0","0","0","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("11","0","2","7272727","10","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("12","0","1","2","200","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("13","0","2","2","90","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("14","0","1","12356","12","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("15","0","1","0","12","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("16","","2","12356","11","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("17","1","2","2","11","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("18","","2","2","14","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("19","","1","12356","10","2019-11-20",NULL);



DROP TABLE IF EXISTS `historial`;

CREATE TABLE `historial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tiempo` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `motivo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_producto` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `historial` VALUES("1","2019-11-05 21:42:52","ingreso","1","100");
INSERT INTO `historial` VALUES("2","2019-11-05 21:46:05","egreso","5","-10");
INSERT INTO `historial` VALUES("3","2019-11-05 21:50:20","ingreso","5","100");
INSERT INTO `historial` VALUES("4","2019-11-08 13:38:04","Egreso","1","-9");
INSERT INTO `historial` VALUES("5","2019-11-08 15:43:29","Ingreso","1","9");
INSERT INTO `historial` VALUES("6","2019-11-08 16:30:41","Ingreso","5","1");
INSERT INTO `historial` VALUES("7","2019-11-20 15:46:33","Egreso","1","-5");
INSERT INTO `historial` VALUES("8","2019-11-20 15:47:22","Egreso","1","-2");



DROP TABLE IF EXISTS `historial_mp`;

CREATE TABLE `historial_mp` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `tiempo` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `motivo` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `id_materia_prima` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_materia_prima` (`id_materia_prima`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `historial_mp` VALUES("1","2019-11-08 15:31:55","ingrero","3","1000");



DROP TABLE IF EXISTS `inventario`;

CREATE TABLE `inventario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_productos` int(11) NOT NULL,
  `estado` enum('aceptado','rechazado') COLLATE utf8_unicode_ci NOT NULL,
  `observaciones` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_entrega` date NOT NULL,
  `fecha_vencimiento` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `inventario_producto` (`id_productos`),
  CONSTRAINT `inventario_producto` FOREIGN KEY (`id_productos`) REFERENCES `productos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `inventario` VALUES("1","1","aceptado","ninguna","160","2019-09-06","2019-09-30");
INSERT INTO `inventario` VALUES("6","2","aceptado","ninguno","440","2019-10-08","0000-00-00");



DROP TABLE IF EXISTS `materia_prima`;

CREATE TABLE `materia_prima` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `presentacion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `unidad` enum('Kgs','Lts') COLLATE utf8_unicode_ci NOT NULL,
  `stock` int(11) NOT NULL,
  `stock_minimo` int(11) NOT NULL,
  `stock_maximo` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `borrado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `activo` enum('S','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `materia_prima` VALUES("1","C1903","XILENO ","BARITANQUE DE 1000 LTS ","Lts","5050","1000","100000","N","S");
INSERT INTO `materia_prima` VALUES("2","2h2h22","madera","tablas","Lts","30","10","40","N","S");
INSERT INTO `materia_prima` VALUES("3","2h2fkfk","agua","paletas","Lts","3000","100","10000","N","S");



DROP TABLE IF EXISTS `materiaprima_producto`;

CREATE TABLE `materiaprima_producto` (
  `id_materiaprima` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad_u_mp` int(90) NOT NULL,
  `cantidad_exist_mp` int(90) NOT NULL,
  KEY `cod_mp` (`id_materiaprima`),
  KEY `cod_p` (`id_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `materiaprima_proveedor`;

CREATE TABLE `materiaprima_proveedor` (
  `id_materiaprima` int(11) NOT NULL,
  `id_proveedor` int(11) NOT NULL,
  `cantidad_c_mp` int(90) NOT NULL,
  `cantidad_exist_mp` int(90) NOT NULL,
  KEY `cod_mp` (`id_materiaprima`),
  KEY `ci_pro` (`id_proveedor`),
  CONSTRAINT `materiaprima_proveedor_ibfk_2` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `nomina`;

CREATE TABLE `nomina` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) NOT NULL,
  `id_prenomina` int(11) NOT NULL,
  `sueldo` varchar(90) NOT NULL,
  `total_asig` varchar(90) NOT NULL,
  `total_deducc` varchar(90) NOT NULL,
  `monto` varchar(90) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_empleado` (`id_empleado`),
  KEY `id_prenomina` (`id_prenomina`),
  CONSTRAINT `nomina_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `nomina_ibfk_2` FOREIGN KEY (`id_prenomina`) REFERENCES `pre_nomina` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `notificaciones`;

CREATE TABLE `notificaciones` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `mensaje` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `notificaciones` VALUES("1","Inventario","1 artÃ­culo requiere atenciÃ³n");
INSERT INTO `notificaciones` VALUES("2","Inventario","1 artÃ­culo requiere atenciÃ³n");
INSERT INTO `notificaciones` VALUES("3","Inventario","2 artÃ­culos requieren atenciÃ³n");
INSERT INTO `notificaciones` VALUES("4","Inventario","2 artÃ­culos requieren atenciÃ³n");



DROP TABLE IF EXISTS `notificaciones_detalles`;

CREATE TABLE `notificaciones_detalles` (
  `id` int(255) NOT NULL,
  `id_notificaciones` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `visto` enum('N','S') COLLATE utf8_unicode_ci DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `pago`;

CREATE TABLE `pago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sueldo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `monto` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `periodo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `pago_ibfk_1` FOREIGN KEY (`id`) REFERENCES `pago_asignaciondeduccion` (`id_pago`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `pago_asignaciondeduccion`;

CREATE TABLE `pago_asignaciondeduccion` (
  `id_pago` int(90) NOT NULL,
  `id_ad` int(90) NOT NULL,
  KEY `id_pago` (`id_pago`),
  KEY `id_ad` (`id_ad`),
  CONSTRAINT `pago_asignaciondeduccion_ibfk_1` FOREIGN KEY (`id_ad`) REFERENCES `asignacion_deduccion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `pedido`;

CREATE TABLE `pedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fecha_edicion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `estado` varchar(60) CHARACTER SET utf8 NOT NULL DEFAULT 'En Espera',
  `tipo` enum('interno','externo') COLLATE utf8_unicode_ci NOT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pedido` VALUES("1","2019-11-07 22:33:58","2019-11-07 22:12:53","Cancelado","interno","1");
INSERT INTO `pedido` VALUES("2","2019-11-08 13:03:06","2019-11-07 22:50:35","Cancelado","interno",NULL);
INSERT INTO `pedido` VALUES("3","2019-11-08 12:13:26","2019-11-08 12:13:26","En Espera","interno",NULL);
INSERT INTO `pedido` VALUES("4","2019-11-08 12:55:36","2019-11-08 12:55:36","En Espera","interno",NULL);
INSERT INTO `pedido` VALUES("6","2019-11-20 12:12:31","2019-11-20 12:12:31","En Espera","interno",NULL);



DROP TABLE IF EXISTS `pedido_detalles`;

CREATE TABLE `pedido_detalles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pedido` int(25) NOT NULL,
  `tiempo_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tiempo_modificado` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `id_producto` int(11) NOT NULL,
  `id_proveedor_personalizado` int(11) DEFAULT NULL,
  `cantidad_solicitada` int(11) NOT NULL,
  `cantidad_despachada` int(11) DEFAULT NULL,
  `observaciones` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pedido_detalles` VALUES("1","2","2019-11-07 22:50:35",NULL,"1",NULL,"10",NULL,NULL);
INSERT INTO `pedido_detalles` VALUES("2","3","2019-11-08 12:13:26",NULL,"2",NULL,"9",NULL,NULL);
INSERT INTO `pedido_detalles` VALUES("3","3","2019-11-08 12:13:26",NULL,"1",NULL,"19",NULL,NULL);
INSERT INTO `pedido_detalles` VALUES("4","4","2019-11-08 12:55:36",NULL,"1",NULL,"9",NULL,NULL);
INSERT INTO `pedido_detalles` VALUES("5","6","2019-11-20 12:12:31",NULL,"1",NULL,"2",NULL,NULL);



DROP TABLE IF EXISTS `permisos`;

CREATE TABLE `permisos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `motivo` enum('Reposo','Permiso') COLLATE utf8_unicode_ci DEFAULT NULL,
  `cantidad_dias` int(11) NOT NULL,
  `inicio_permiso` date NOT NULL,
  `fin_permiso` date NOT NULL,
  `resta` int(11) NOT NULL,
  `status` enum('En Curso','Cumplido') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'En Curso',
  `id_empleado` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `dias_permiso` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `permisos` VALUES("1","Reposo","3","2019-11-10","2019-11-12","0","Cumplido","3");
INSERT INTO `permisos` VALUES("2","Permiso","3","2019-10-20","2019-10-22","3","Cumplido","3");
INSERT INTO `permisos` VALUES("3","Reposo","4","2019-11-12","2019-11-15","3","En Curso","2");



DROP TABLE IF EXISTS `pre_nomina`;

CREATE TABLE `pre_nomina` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quincena` int(90) NOT NULL,
  `mes` int(90) NOT NULL,
  `anio` int(90) NOT NULL,
  `status` enum('Procesando','Aprobado') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `pre_nomina` VALUES("3","1","10","2019","Procesando");



DROP TABLE IF EXISTS `prenomina_empleado`;

CREATE TABLE `prenomina_empleado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_prenomina` int(11) NOT NULL,
  `id_empleado` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_prenomina` (`id_prenomina`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `prenomina_empleado_ibfk_1` FOREIGN KEY (`id_prenomina`) REFERENCES `pre_nomina` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `prenomina_empleado_ibfk_2` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `prenomina_empleado` VALUES("7","3","1");
INSERT INTO `prenomina_empleado` VALUES("8","3","2");
INSERT INTO `prenomina_empleado` VALUES("9","3","3");



DROP TABLE IF EXISTS `privilegios`;

CREATE TABLE `privilegios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `modulo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `privilegio` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `privilegios` VALUES("1","proveedor","registrar");
INSERT INTO `privilegios` VALUES("2","proveedor","listado");
INSERT INTO `privilegios` VALUES("3","proveedor","modificar");
INSERT INTO `privilegios` VALUES("4","proveedor","eliminar");
INSERT INTO `privilegios` VALUES("5","materiaprima","registrar");
INSERT INTO `privilegios` VALUES("6","materiaprima","listado");
INSERT INTO `privilegios` VALUES("7","materiaprima","modificar");
INSERT INTO `privilegios` VALUES("8","materiaprima","eliminar");
INSERT INTO `privilegios` VALUES("9","inventario","registrar");
INSERT INTO `privilegios` VALUES("10","inventario","listado");
INSERT INTO `privilegios` VALUES("11","inventario","modificar");
INSERT INTO `privilegios` VALUES("12","inventario","eliminar");
INSERT INTO `privilegios` VALUES("13","empleado","registrar");
INSERT INTO `privilegios` VALUES("14","empleado","listado");
INSERT INTO `privilegios` VALUES("15","empleado","modificar");
INSERT INTO `privilegios` VALUES("16","empleado","eliminar");
INSERT INTO `privilegios` VALUES("17","asistencia","registrar");
INSERT INTO `privilegios` VALUES("18","asistencia","listado");
INSERT INTO `privilegios` VALUES("19","asistencia","modificar");
INSERT INTO `privilegios` VALUES("20","asistencia","eliminar");
INSERT INTO `privilegios` VALUES("21","asigdeducc","registrar");
INSERT INTO `privilegios` VALUES("22","asigdeducc","listado");
INSERT INTO `privilegios` VALUES("23","asigdeducc","modificar");
INSERT INTO `privilegios` VALUES("24","asigdeducc","eliminar");
INSERT INTO `privilegios` VALUES("25","nomina","registrar");
INSERT INTO `privilegios` VALUES("26","nomina","listado");
INSERT INTO `privilegios` VALUES("27","nomina","modificar");
INSERT INTO `privilegios` VALUES("28","nomina","eliminar");
INSERT INTO `privilegios` VALUES("32","mantenimiento","bitacora");
INSERT INTO `privilegios` VALUES("33","mantenimiento","respaldo");
INSERT INTO `privilegios` VALUES("34","mantenimiento","recuperacion");
INSERT INTO `privilegios` VALUES("35","mantenimiento","listado");



DROP TABLE IF EXISTS `produccion`;

CREATE TABLE `produccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_producto` int(11) NOT NULL,
  `cantidad` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `paletas` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `observacion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `status` enum('Sin Almacenar','Almacenando','Completo') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `producto_proveedor`;

CREATE TABLE `producto_proveedor` (
  `id` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `id_proveedor` int(11) NOT NULL,
  `cantidad_d_p` int(90) NOT NULL,
  `cantidad_exist_p` int(90) NOT NULL,
  KEY `cod_p` (`id_producto`),
  KEY `ci_pro` (`id_proveedor`),
  CONSTRAINT `producto_proveedor_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `productos`;

CREATE TABLE `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `presentacion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `unidad` enum('Kgs','Lts') COLLATE utf8_unicode_ci NOT NULL,
  `stock` int(11) NOT NULL,
  `stock_minimo` int(11) NOT NULL,
  `stock_maximo` int(11) NOT NULL,
  `borrado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `activo` enum('S','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `valor_unitario` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `productos` VALUES("1","12356","hierro","paletas","Kgs","3","5","30","N","S",NULL);
INSERT INTO `productos` VALUES("2","7272727","metal","paletas","Lts","80","10","5000","N","S",NULL);
INSERT INTO `productos` VALUES("3","nuh779","cosa","paletas","Kgs","10","10","200","N","S",NULL);
INSERT INTO `productos` VALUES("4","32020","madera","flota","Lts","56","10","100","N","N",NULL);
INSERT INTO `productos` VALUES("5","2h2h22","koll","tablas","Lts","870","9","900","N","S",NULL);



DROP TABLE IF EXISTS `proveedor`;

CREATE TABLE `proveedor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cod_rif` enum('V','J','E','G') COLLATE utf8_unicode_ci NOT NULL,
  `cedula` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `borrado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `proveedor` VALUES("2","V","25873122","Juan Carlos Figueredo","juan2912@gmail.com","La Victoria","3163502","N");
INSERT INTO `proveedor` VALUES("4","J","J-1345678","Inica Cagua C.A","inicacca@gmail.com","Cagua ","9876556","S");
INSERT INTO `proveedor` VALUES("5","V","29554496","holahhh","holgggggga@gmail.com","aahha","23456787654","N");
INSERT INTO `proveedor` VALUES("6","V","23353454","esaaaaaa","","gagu","342342323","N");
INSERT INTO `proveedor` VALUES("7","V","099988","koll","hectorher149@gmail.com","","8889998","S");



DROP TABLE IF EXISTS `recibidos`;

CREATE TABLE `recibidos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pmp` int(11) NOT NULL,
  `cantidad` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `observacion` varchar(90) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ce` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `recibidos` VALUES("2","1","102002","2019-10-07","8jjkk","");



DROP TABLE IF EXISTS `ubicacion`;

CREATE TABLE `ubicacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `bloqueado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `borrado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tipo` enum('I','E') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `ubicacion` VALUES("1","produccion","N","N","I");
INSERT INTO `ubicacion` VALUES("2","almacen","N","N","I");



DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `correo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `clave` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_usuario` enum('Admin','Usuario 1','Usuario 2') COLLATE utf8_unicode_ci NOT NULL,
  `pregunta` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `respuesta` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `borrado` enum('S','N') COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `usuarios` VALUES("1","Daileska Vilera","dvilera610@gmail.com","044598473886535a33126083e3d2e1170e4a67befe897a83ad95a33209a64b3a","Usuario 2","Mascota","Sandy","S");
INSERT INTO `usuarios` VALUES("2","hector hernandez","hectorher149@gmail.com","8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92","Admin","nombre de mascota","body","N");
INSERT INTO `usuarios` VALUES("3","Alejandro","darvisalfonso@gmail.com","67d9f1c944a4ee6ef3634298c97639c81927a228d6aa490b343abf594e45aecf","Usuario 1","nombre de mascota","pelusa","S");
INSERT INTO `usuarios` VALUES("4","Genessi","genessie@gmail.com","8491502322172e09ec7222d33941d33afbfcc22ab0c4dd1033dd72232308675a","Admin","mes de nacimiento","noviembre","S");
