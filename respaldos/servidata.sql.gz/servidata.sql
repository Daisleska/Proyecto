CREATE DATABASE IF NOT EXISTS `servidata`;

USE servidata;

DROP TABLE IF EXISTS `almacen`;

CREATE TABLE `almacen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_producto` int(11) NOT NULL,
  `id_ubicacion` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `ce` varchar(90) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paletas` varchar(90) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_producto` (`id_producto`),
  KEY `id_ubicacion` (`id_ubicacion`),
  CONSTRAINT `almacen_ibfk_1` FOREIGN KEY (`id_ubicacion`) REFERENCES `ubicacion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `almacen` VALUES("8","8","2","70",NULL,NULL);



DROP TABLE IF EXISTS `asignacion_deduccion`;

CREATE TABLE `asignacion_deduccion` (
  `id` int(90) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `tipo` enum('Asignacion','Deduccion') COLLATE utf8_unicode_ci NOT NULL,
  `monto` int(90) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_tipo` (`tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `asignacion_deduccion` VALUES("1","Memoriales La Victoria C.A","Deduccion","15000");
INSERT INTO `asignacion_deduccion` VALUES("2","Prima por Hijo","Asignacion","50000");
INSERT INTO `asignacion_deduccion` VALUES("4","Prima Prof. TSU","Asignacion","65000");



DROP TABLE IF EXISTS `asistencias`;

CREATE TABLE `asistencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) NOT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'fecha de asistencia',
  `status` enum('A','NACJ','NASJ','Sin Marcar') COLLATE utf8_unicode_ci NOT NULL,
  `justificacion` enum('Permiso','Reposo','','') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rest_asis` (`id_empleado`),
  CONSTRAINT `rest_asis` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `asistencias` VALUES("4","1","2019-11-13 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("5","3","2019-11-13 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("6","1","2019-11-15 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("7","1","2019-11-16 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("8","1","2019-11-21 00:00:00","A","");
INSERT INTO `asistencias` VALUES("9","3","2019-11-21 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("10","1","2019-11-22 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("11","1","2019-11-27 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("12","2","2019-11-27 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("13","3","2019-11-27 00:00:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("14","1","2019-11-24 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("15","1","2019-11-25 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("16","2","2019-11-25 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("17","1","2019-12-01 00:30:00","A","");
INSERT INTO `asistencias` VALUES("18","1","2019-12-02 00:30:00","NASJ","");
INSERT INTO `asistencias` VALUES("19","2","2019-12-02 00:30:00","NASJ","");
INSERT INTO `asistencias` VALUES("20","4","2019-12-02 00:30:00","A","");
INSERT INTO `asistencias` VALUES("21","1","2019-12-04 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("22","2","2019-12-04 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("23","3","2019-12-04 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("24","4","2019-12-04 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("25","1","2019-12-17 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("26","2","2019-12-17 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("27","3","2019-12-17 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("28","4","2019-12-17 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("29","1","2019-12-18 00:30:00","A","");
INSERT INTO `asistencias` VALUES("30","2","2019-12-18 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("31","3","2019-12-18 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("32","4","2019-12-18 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("33","1","2019-12-19 00:30:00","A","");
INSERT INTO `asistencias` VALUES("34","3","2019-12-19 00:30:00","NASJ","");
INSERT INTO `asistencias` VALUES("35","4","2019-12-19 00:30:00","A","");
INSERT INTO `asistencias` VALUES("36","1","2020-01-05 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("37","1","2020-01-06 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("38","2","2020-01-06 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("39","4","2020-01-06 00:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("40","1","2020-04-29 23:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("41","3","2020-04-29 23:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("42","4","2020-04-29 23:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("43","1","2020-05-18 23:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("44","2","2020-05-18 23:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("45","3","2020-05-18 23:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("46","4","2020-05-18 23:30:00","Sin Marcar","");
INSERT INTO `asistencias` VALUES("47","1","2020-09-22 23:30:00","A","");
INSERT INTO `asistencias` VALUES("48","2","2020-09-22 23:30:00","A","");
INSERT INTO `asistencias` VALUES("49","3","2020-09-22 23:30:00","A","");
INSERT INTO `asistencias` VALUES("50","4","2020-09-22 23:30:00","NASJ","");
INSERT INTO `asistencias` VALUES("51","1","2021-03-14 00:30:00","A","");



DROP TABLE IF EXISTS `auditoria`;

CREATE TABLE `auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `actividad` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `tabla` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `auditoria` VALUES("70","1","modificÃ³ empleados","empleados","2019-12-01 15:23:03","Usuario 2");
INSERT INTO `auditoria` VALUES("71","1","modificÃ³ empleados","empleados","2019-12-01 15:23:48","Usuario 2");
INSERT INTO `auditoria` VALUES("72","1","modificÃ³ empleados","empleados","2019-12-01 15:26:14","Usuario 2");
INSERT INTO `auditoria` VALUES("73","1","modificÃ³ empleados","empleados","2019-12-01 15:31:23","Usuario 2");
INSERT INTO `auditoria` VALUES("75","2","aprobÃ³ segunda quincena","pre_nomina","2019-12-01 22:36:12","Admin");
INSERT INTO `auditoria` VALUES("76","2","generÃ³ primera quincena","pre_nomina","2019-12-01 22:47:57","Admin");
INSERT INTO `auditoria` VALUES("77","2","generÃ³ primera quincena","pre_nomina","2019-12-01 22:47:57","Admin");
INSERT INTO `auditoria` VALUES("78","2","generÃ³ primera quincena","pre_nomina","2019-12-01 22:47:58","Admin");
INSERT INTO `auditoria` VALUES("79","2","generÃ³ primera quincena","pre_nomina","2019-12-01 22:47:58","Admin");
INSERT INTO `auditoria` VALUES("80","2","eliminÃ³ quincena","pre_nomina","2019-12-01 22:48:52","Admin");
INSERT INTO `auditoria` VALUES("81","2","modificÃ³ cargos","cargos","2019-12-01 22:51:34","Admin");
INSERT INTO `auditoria` VALUES("82","2","generÃ³ primera quincena","pre_nomina","2019-12-01 22:53:04","Admin");
INSERT INTO `auditoria` VALUES("83","2","generÃ³ primera quincena","pre_nomina","2019-12-01 22:53:04","Admin");
INSERT INTO `auditoria` VALUES("84","2","generÃ³ primera quincena","pre_nomina","2019-12-01 22:53:05","Admin");
INSERT INTO `auditoria` VALUES("85","2","generÃ³ primera quincena","pre_nomina","2019-12-01 22:53:05","Admin");
INSERT INTO `auditoria` VALUES("86","2","eliminÃ³ quincena","pre_nomina","2019-12-01 22:55:35","Admin");
INSERT INTO `auditoria` VALUES("87","2","generÃ³ primera quincena","pre_nomina","2019-12-01 22:55:40","Admin");
INSERT INTO `auditoria` VALUES("88","2","generÃ³ primera quincena","pre_nomina","2019-12-01 22:55:40","Admin");
INSERT INTO `auditoria` VALUES("89","2","generÃ³ primera quincena","pre_nomina","2019-12-01 22:55:40","Admin");
INSERT INTO `auditoria` VALUES("90","2","generÃ³ primera quincena","pre_nomina","2019-12-01 22:55:40","Admin");
INSERT INTO `auditoria` VALUES("91","2","modificÃ³ perfil","usuarios","2019-12-01 23:16:45","Admin");
INSERT INTO `auditoria` VALUES("92","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-01 23:46:39","");
INSERT INTO `auditoria` VALUES("93","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-01 23:47:58","");
INSERT INTO `auditoria` VALUES("94","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-01 23:48:12","");
INSERT INTO `auditoria` VALUES("95","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-01 23:48:37","");
INSERT INTO `auditoria` VALUES("96","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-01 23:48:57","");
INSERT INTO `auditoria` VALUES("97","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-01 23:57:29","");
INSERT INTO `auditoria` VALUES("98","2","iniciÃ³ sesiÃ³n","usuarios","2019-12-02 00:49:16","Admin");
INSERT INTO `auditoria` VALUES("99","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-02 00:49:57","");
INSERT INTO `auditoria` VALUES("100","1","iniciÃ³ sesiÃ³n","usuarios","2019-12-02 00:57:11","Usuario 2");
INSERT INTO `auditoria` VALUES("101","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-04 10:48:13","");
INSERT INTO `auditoria` VALUES("102","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-04 11:14:12","");
INSERT INTO `auditoria` VALUES("103","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-04 11:21:05","");
INSERT INTO `auditoria` VALUES("104","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-17 17:16:10","");
INSERT INTO `auditoria` VALUES("105","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-17 18:08:22","");
INSERT INTO `auditoria` VALUES("106","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-17 18:11:26","");
INSERT INTO `auditoria` VALUES("107","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-18 16:29:30","");
INSERT INTO `auditoria` VALUES("108","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-18 16:29:50","");
INSERT INTO `auditoria` VALUES("109","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-18 16:32:08","");
INSERT INTO `auditoria` VALUES("110","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-18 16:35:04","");
INSERT INTO `auditoria` VALUES("111","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-18 16:36:16","");
INSERT INTO `auditoria` VALUES("112","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-18 17:22:00","");
INSERT INTO `auditoria` VALUES("113","1","iniciÃ³ sesiÃ³n","usuarios","2019-12-18 18:49:21","Usuario 2");
INSERT INTO `auditoria` VALUES("114","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-18 20:11:11","");
INSERT INTO `auditoria` VALUES("115","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-19 13:36:46","");
INSERT INTO `auditoria` VALUES("116","0","iniciÃ³ sesiÃ³n","usuarios","2019-12-19 14:04:36","");
INSERT INTO `auditoria` VALUES("117","0","iniciÃ³ sesiÃ³n","usuarios","2020-01-05 15:56:56","");
INSERT INTO `auditoria` VALUES("118","0","iniciÃ³ sesiÃ³n","usuarios","2019-07-22 14:58:22","");
INSERT INTO `auditoria` VALUES("119","0","iniciÃ³ sesiÃ³n","usuarios","2020-01-05 20:21:18","");
INSERT INTO `auditoria` VALUES("120","0","iniciÃ³ sesiÃ³n","usuarios","2020-01-05 20:22:39","");
INSERT INTO `auditoria` VALUES("121","0","iniciÃ³ sesiÃ³n","usuarios","2020-01-05 20:36:40","");
INSERT INTO `auditoria` VALUES("122","0","iniciÃ³ sesiÃ³n","usuarios","2020-01-25 11:21:10","");
INSERT INTO `auditoria` VALUES("123","0","iniciÃ³ sesiÃ³n","usuarios","2020-01-25 11:24:17","");
INSERT INTO `auditoria` VALUES("124","0","iniciÃ³ sesiÃ³n","usuarios","2020-02-06 00:44:21","");
INSERT INTO `auditoria` VALUES("125","0","iniciÃ³ sesiÃ³n","usuarios","2020-02-06 00:52:48","");
INSERT INTO `auditoria` VALUES("126","0","iniciÃ³ sesiÃ³n","usuarios","2020-02-14 14:29:04","");
INSERT INTO `auditoria` VALUES("127","0","iniciÃ³ sesiÃ³n","usuarios","2020-03-15 15:48:12","");
INSERT INTO `auditoria` VALUES("128","0","iniciÃ³ sesiÃ³n","usuarios","2020-03-16 15:04:28","");
INSERT INTO `auditoria` VALUES("129","2","iniciÃ³ sesiÃ³n","usuarios","2020-03-17 00:24:58","Admin");
INSERT INTO `auditoria` VALUES("130","0","iniciÃ³ sesiÃ³n","usuarios","2020-03-31 15:59:48","");
INSERT INTO `auditoria` VALUES("131","0","iniciÃ³ sesiÃ³n","usuarios","2020-04-29 22:59:37","");
INSERT INTO `auditoria` VALUES("132","0","iniciÃ³ sesiÃ³n","usuarios","2020-04-30 23:19:30","");
INSERT INTO `auditoria` VALUES("133","0","iniciÃ³ sesiÃ³n","usuarios","2020-04-30 17:42:25","");
INSERT INTO `auditoria` VALUES("134","0","iniciÃ³ sesiÃ³n","usuarios","2020-05-05 14:32:56","");
INSERT INTO `auditoria` VALUES("135","0","iniciÃ³ sesiÃ³n","usuarios","2020-05-19 16:30:35","");
INSERT INTO `auditoria` VALUES("136","0","iniciÃ³ sesiÃ³n","usuarios","2020-05-20 22:32:29","");
INSERT INTO `auditoria` VALUES("137","0","iniciÃ³ sesiÃ³n","usuarios","2020-09-22 18:05:12","");
INSERT INTO `auditoria` VALUES("138","0","iniciÃ³ sesiÃ³n","usuarios","2020-09-22 22:31:17","");
INSERT INTO `auditoria` VALUES("139","0","iniciÃ³ sesiÃ³n","usuarios","2020-09-23 16:41:42","");
INSERT INTO `auditoria` VALUES("140","0","iniciÃ³ sesiÃ³n","usuarios","2020-11-07 18:20:41","");
INSERT INTO `auditoria` VALUES("141","0","iniciÃ³ sesiÃ³n","usuarios","2020-11-07 18:28:56","");
INSERT INTO `auditoria` VALUES("142","0","iniciÃ³ sesiÃ³n","usuarios","2021-03-14 14:48:55","");
INSERT INTO `auditoria` VALUES("143","1","aprobÃ³ primera quincena","pre_nomina","2021-03-14 15:01:06","Usuario 2");
INSERT INTO `auditoria` VALUES("144","1","generÃ³ primera quincena","pre_nomina","2021-03-14 15:01:40","Usuario 2");
INSERT INTO `auditoria` VALUES("145","1","generÃ³ primera quincena","pre_nomina","2021-03-14 15:01:40","Usuario 2");
INSERT INTO `auditoria` VALUES("146","1","generÃ³ primera quincena","pre_nomina","2021-03-14 15:01:40","Usuario 2");
INSERT INTO `auditoria` VALUES("147","1","generÃ³ primera quincena","pre_nomina","2021-03-14 15:01:41","Usuario 2");
INSERT INTO `auditoria` VALUES("148","0","iniciÃ³ sesiÃ³n","usuarios","2021-03-26 18:51:09","");
INSERT INTO `auditoria` VALUES("149","0","iniciÃ³ sesiÃ³n","usuarios","2021-03-26 22:06:28","");



DROP TABLE IF EXISTS `cargos`;

CREATE TABLE `cargos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `salario` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `id_departamento` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_departamentos` (`id_departamento`),
  CONSTRAINT `rest_departamento` FOREIGN KEY (`id_departamento`) REFERENCES `departamentos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cargos` VALUES("1","Jefe","1500000","2");
INSERT INTO `cargos` VALUES("2","Asistente","400000","2");



DROP TABLE IF EXISTS `cestaticket`;

CREATE TABLE `cestaticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `monto` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cestaticket` VALUES("5","25000");



DROP TABLE IF EXISTS `departamentos`;

CREATE TABLE `departamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `departamentos` VALUES("1","Almacen");
INSERT INTO `departamentos` VALUES("2","Recursos Humanos");



DROP TABLE IF EXISTS `despachos`;

CREATE TABLE `despachos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_almacen` int(11) NOT NULL,
  `cantidad` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `paletas` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `observacion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `destino` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `dia_lab`;

CREATE TABLE `dia_lab` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rest_dia` (`id_empleado`),
  CONSTRAINT `rest_dia` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `dia_lab` VALUES("31","1"," Lunes");
INSERT INTO `dia_lab` VALUES("32","1"," Martes");
INSERT INTO `dia_lab` VALUES("33","1"," MiÃ©rcoles");
INSERT INTO `dia_lab` VALUES("34","1"," Jueves");
INSERT INTO `dia_lab` VALUES("35","1"," Viernes");
INSERT INTO `dia_lab` VALUES("36","1"," SÃ¡bado");
INSERT INTO `dia_lab` VALUES("37","1"," Domingo");
INSERT INTO `dia_lab` VALUES("41","2"," Lunes");
INSERT INTO `dia_lab` VALUES("42","2"," Martes");
INSERT INTO `dia_lab` VALUES("43","2"," MiÃ©rcoles");
INSERT INTO `dia_lab` VALUES("44","3"," Martes");
INSERT INTO `dia_lab` VALUES("45","3"," MiÃ©rcoles");
INSERT INTO `dia_lab` VALUES("46","3"," Jueves");
INSERT INTO `dia_lab` VALUES("47","4"," Lunes");
INSERT INTO `dia_lab` VALUES("48","4"," Martes");
INSERT INTO `dia_lab` VALUES("49","4"," MiÃ©rcoles");
INSERT INTO `dia_lab` VALUES("50","4"," Jueves");
INSERT INTO `dia_lab` VALUES("51","4"," Viernes");



DROP TABLE IF EXISTS `empleado`;

CREATE TABLE `empleado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `nombres` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `apellidos` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `condicion` enum('Fijo','Contratado') COLLATE utf8_unicode_ci NOT NULL,
  `fecha_venc` date NOT NULL,
  `ncuenta` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `id_cargo` int(11) NOT NULL,
  `id_departamento` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cargo` (`id_cargo`),
  CONSTRAINT `rest_cargo` FOREIGN KEY (`id_cargo`) REFERENCES `cargos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `empleado` VALUES("1","25873122","Juan Carlos","Figueredo EspaÃ±a","La Victoria","04243160235","2019-10-25","Contratado","2020-02-25","01354567898765432345","2","1");
INSERT INTO `empleado` VALUES("2","28147989","HÃ©ctor Argenis","HernÃ¡ndez Ceballos","San Mateo","04243590130","2019-09-18","Fijo","2022-02-16","01915678890998787654","1","2");
INSERT INTO `empleado` VALUES("3","18610668","Eynsterd Samuel","BriceÃ±o Velazco","Zuata","04163462604","2019-11-20","Contratado","2020-04-20","01027693406500432765","2","1");
INSERT INTO `empleado` VALUES("4","17896543","Luis Alberto ","Montilla Raga","Zuata","04124808765","2019-11-05","Contratado","2020-03-11","01029764863298007658","2","2");



DROP TABLE IF EXISTS `empleado_asig`;

CREATE TABLE `empleado_asig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) NOT NULL,
  `id_asignaciones` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `empl` (`id_empleado`),
  KEY `asig` (`id_asignaciones`),
  CONSTRAINT `asig` FOREIGN KEY (`id_asignaciones`) REFERENCES `asignacion_deduccion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `empl` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `empleado_asig` VALUES("1","1","2");
INSERT INTO `empleado_asig` VALUES("2","1","1");
INSERT INTO `empleado_asig` VALUES("3","2","1");
INSERT INTO `empleado_asig` VALUES("4","2","2");
INSERT INTO `empleado_asig` VALUES("5","3","1");
INSERT INTO `empleado_asig` VALUES("6","3","2");
INSERT INTO `empleado_asig` VALUES("7","3","4");
INSERT INTO `empleado_asig` VALUES("9","4","1");
INSERT INTO `empleado_asig` VALUES("10","4","2");
INSERT INTO `empleado_asig` VALUES("11","4","4");



DROP TABLE IF EXISTS `enviados`;

CREATE TABLE `enviados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_productos` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `id_ubicacion` int(11) NOT NULL,
  `codigo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_registro` date NOT NULL,
  `observacion` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ubicacion` (`id_ubicacion`),
  KEY `id_codigo` (`codigo`),
  KEY `id_productos` (`id_productos`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `enviados` VALUES("1","0","2","0","100","2019-11-06",NULL);
INSERT INTO `enviados` VALUES("2","0","2","0","100","2019-11-06",NULL);
INSERT INTO `enviados` VALUES("3","0","2","0","40","2019-11-06",NULL);
INSERT INTO `enviados` VALUES("4","0","2","0","1000","2019-11-06",NULL);
INSERT INTO `enviados` VALUES("5","0","2","0","100","2019-11-06",NULL);
INSERT INTO `enviados` VALUES("6","0","2","0","10","2019-11-06",NULL);
INSERT INTO `enviados` VALUES("7","0","1","0","50","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("8","0","2","0","50","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("9","0","1","0","100","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("10","0","0","0","0","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("11","0","2","7272727","10","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("12","0","1","2","200","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("13","0","2","2","90","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("14","0","1","12356","12","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("15","0","1","0","12","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("16","","2","12356","11","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("17","1","2","2","11","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("18","","2","2","14","2019-11-08",NULL);
INSERT INTO `enviados` VALUES("19","","1","12356","10","2019-11-20",NULL);
INSERT INTO `enviados` VALUES("20","7","0","70706","55","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("21","7","0","70706","55","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("22","1","0","12356","8","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("23","2","0","7272727","90","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("24","2","0","7272727","40","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("25","5","0","2","4","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("26","5","0","2","4","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("27","5","2","2","4","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("28","5","2","2h2h22","4","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("29","5","2","2h2h22","4","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("30","5","2","2h2h22","5","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("31","5","2","2h2h22","4","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("32","5","2","2h2h22","4","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("33","7","2","70706","50","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("34","<br />\n<b>Notice</b>:  Undefined variable: consulta in <b>C:xampphhtdocsProyectoVistasinv","2","70706","50","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("35","7","2","70706","50","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("36","7","2","70706","50","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("37","7","2","70706","50","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("38","7","2","70706","50","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("39","7","2","70706","50","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("40","7","2","70706","5","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("41","7","2","70706","51","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("42","7","2","70706","4","2019-11-27",NULL);
INSERT INTO `enviados` VALUES("43","8","2","CE007","50","2019-12-01",NULL);
INSERT INTO `enviados` VALUES("44","8","2","CE007","10","2019-12-01",NULL);
INSERT INTO `enviados` VALUES("45","8","2","CE007","50","2020-01-25",NULL);



DROP TABLE IF EXISTS `historial`;

CREATE TABLE `historial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tiempo` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `motivo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_producto` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `historial` VALUES("1","2019-11-05 21:42:52","ingreso","1","100");
INSERT INTO `historial` VALUES("2","2019-11-05 21:46:05","egreso","5","-10");
INSERT INTO `historial` VALUES("3","2019-11-05 21:50:20","ingreso","5","100");
INSERT INTO `historial` VALUES("4","2019-11-08 13:38:04","Egreso","1","-9");
INSERT INTO `historial` VALUES("5","2019-11-08 15:43:29","Ingreso","1","9");
INSERT INTO `historial` VALUES("6","2019-11-08 16:30:41","Ingreso","5","1");
INSERT INTO `historial` VALUES("7","2019-11-20 15:46:33","Egreso","1","-5");
INSERT INTO `historial` VALUES("8","2019-11-20 15:47:22","Egreso","1","-2");
INSERT INTO `historial` VALUES("9","2019-11-21 15:22:47","Registro","6","10000");
INSERT INTO `historial` VALUES("10","2019-11-27 01:37:06","Registro","7","2000");
INSERT INTO `historial` VALUES("11","2019-11-27 01:37:57","Egreso","7","55");
INSERT INTO `historial` VALUES("12","2019-12-01 15:49:07","Registro","8","100");
INSERT INTO `historial` VALUES("13","2019-12-01 18:11:41","Egreso","8","200");
INSERT INTO `historial` VALUES("14","2020-01-25 10:58:25","Egreso","8","100");



DROP TABLE IF EXISTS `historial_mp`;

CREATE TABLE `historial_mp` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `tiempo` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `motivo` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `id_materia_prima` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_materia_prima` (`id_materia_prima`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `historial_mp` VALUES("1","2019-11-08 15:31:55","ingrero","3","1000");



DROP TABLE IF EXISTS `inventario`;

CREATE TABLE `inventario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_productos` int(11) NOT NULL,
  `estado` enum('aceptado','rechazado') COLLATE utf8_unicode_ci NOT NULL,
  `observaciones` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_entrega` date NOT NULL,
  `fecha_vencimiento` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `inventario_producto` (`id_productos`),
  CONSTRAINT `inventario_producto` FOREIGN KEY (`id_productos`) REFERENCES `productos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `materia_prima`;

CREATE TABLE `materia_prima` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `presentacion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `unidad` enum('Kgs','Lts') COLLATE utf8_unicode_ci NOT NULL,
  `stock` int(11) NOT NULL,
  `stock_minimo` int(11) NOT NULL,
  `stock_maximo` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `borrado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `activo` enum('S','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `materia_prima` VALUES("1","C1903","XILENO ","BARITANQUE DE 1000 LTS ","Lts","5050","1000","100000","N","S");



DROP TABLE IF EXISTS `nomina`;

CREATE TABLE `nomina` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) NOT NULL,
  `id_prenomina` int(11) NOT NULL,
  `sueldo` varchar(90) NOT NULL,
  `total_asig` varchar(90) NOT NULL,
  `total_deducc` varchar(90) NOT NULL,
  `monto` varchar(90) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_empleado` (`id_empleado`),
  KEY `id_prenomina` (`id_prenomina`),
  CONSTRAINT `nomina_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `nomina_ibfk_2` FOREIGN KEY (`id_prenomina`) REFERENCES `pre_nomina` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO `nomina` VALUES("16","1","6","200000","250000","15000","235000");
INSERT INTO `nomina` VALUES("17","2","6","50400","100400","15000","85400");
INSERT INTO `nomina` VALUES("18","3","6","200000","315000","15000","300000");
INSERT INTO `nomina` VALUES("19","1","7","200000","275000","15000","260000");
INSERT INTO `nomina` VALUES("20","2","7","50400","75400","15000","60400");
INSERT INTO `nomina` VALUES("21","3","7","200000","340000","15000","325000");
INSERT INTO `nomina` VALUES("22","1","10","200000","250000","15000","235000");
INSERT INTO `nomina` VALUES("23","2","10","750000","800000","15000","785000");
INSERT INTO `nomina` VALUES("24","3","10","200000","315000","15000","300000");
INSERT INTO `nomina` VALUES("25","4","10","200000","315000","15000","300000");



DROP TABLE IF EXISTS `notificaciones`;

CREATE TABLE `notificaciones` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `mensaje` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `notificaciones` VALUES("1","Inventario","1 artÃ­culo requiere atenciÃ³n");
INSERT INTO `notificaciones` VALUES("2","Inventario","1 artÃ­culo requiere atenciÃ³n");
INSERT INTO `notificaciones` VALUES("3","Inventario","2 artÃ­culos requieren atenciÃ³n");
INSERT INTO `notificaciones` VALUES("4","Inventario","2 artÃ­culos requieren atenciÃ³n");
INSERT INTO `notificaciones` VALUES("5","Inventario","1 artÃ­culo requiere atenciÃ³n");
INSERT INTO `notificaciones` VALUES("6","Pedido interno","Tienes 2 pedidos internos en espera");
INSERT INTO `notificaciones` VALUES("7","Inventario","1 artÃ­culo requiere atenciÃ³n");
INSERT INTO `notificaciones` VALUES("8","Pedido interno","Tienes 2 pedidos internos en espera");
INSERT INTO `notificaciones` VALUES("9","Pedido interno","Tienes 2 pedidos internos en espera");
INSERT INTO `notificaciones` VALUES("10","Pedido interno","Tienes un pedido interno en espera");



DROP TABLE IF EXISTS `notificaciones_detalles`;

CREATE TABLE `notificaciones_detalles` (
  `id` int(255) NOT NULL,
  `id_notificaciones` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `visto` enum('N','S') COLLATE utf8_unicode_ci DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `pedido`;

CREATE TABLE `pedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fecha_edicion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `estado` varchar(60) CHARACTER SET utf8 NOT NULL DEFAULT 'En Espera',
  `tipo` enum('interno','externo') COLLATE utf8_unicode_ci NOT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pedido` VALUES("1","2019-11-07 22:33:58","2019-11-07 22:12:53","Cancelado","interno","1");
INSERT INTO `pedido` VALUES("2","2019-11-08 13:03:06","2019-11-07 22:50:35","Cancelado","interno",NULL);
INSERT INTO `pedido` VALUES("3","2019-12-01 19:25:42","2019-11-08 12:13:26","Cancelado","interno",NULL);
INSERT INTO `pedido` VALUES("4","2019-12-01 19:25:35","2019-11-08 12:55:36","Cancelado","interno",NULL);
INSERT INTO `pedido` VALUES("6","2019-11-26 22:05:50","2019-11-20 12:12:31","Completado","interno",NULL);
INSERT INTO `pedido` VALUES("7","2019-11-27 01:37:57","2019-11-27 01:37:46","Completado","interno",NULL);
INSERT INTO `pedido` VALUES("8","2019-12-01 18:41:41","2019-12-01 18:39:49","Completado","interno",NULL);
INSERT INTO `pedido` VALUES("9","2019-12-01 19:27:27","2019-12-01 19:27:27","En Espera","interno",NULL);
INSERT INTO `pedido` VALUES("11","2020-01-25 11:28:25","2020-01-25 11:27:27","Completado","interno",NULL);



DROP TABLE IF EXISTS `pedido_detalles`;

CREATE TABLE `pedido_detalles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pedido` int(25) NOT NULL,
  `tiempo_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tiempo_modificado` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `id_producto` int(11) NOT NULL,
  `id_proveedor_personalizado` int(11) DEFAULT NULL,
  `cantidad_solicitada` int(11) NOT NULL,
  `cantidad_despachada` int(11) DEFAULT NULL,
  `observaciones` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pedido_detalles` VALUES("1","2","2019-11-07 22:50:35",NULL,"1",NULL,"10",NULL,NULL);
INSERT INTO `pedido_detalles` VALUES("2","3","2019-11-08 12:13:26",NULL,"2",NULL,"9",NULL,NULL);
INSERT INTO `pedido_detalles` VALUES("3","3","2019-11-08 12:13:26",NULL,"1",NULL,"19",NULL,NULL);
INSERT INTO `pedido_detalles` VALUES("4","4","2019-11-08 12:55:36",NULL,"1",NULL,"9",NULL,NULL);
INSERT INTO `pedido_detalles` VALUES("5","6","2019-11-20 12:12:31","2019-11-26 22:05:50","1",NULL,"2","2",NULL);
INSERT INTO `pedido_detalles` VALUES("6","7","2019-11-27 01:37:46","2019-11-27 01:37:57","7",NULL,"55","55",NULL);
INSERT INTO `pedido_detalles` VALUES("7","8","2019-12-01 18:39:49","2019-12-01 18:41:40","8",NULL,"200","200",NULL);
INSERT INTO `pedido_detalles` VALUES("8","9","2019-12-01 19:27:27",NULL,"8",NULL,"50",NULL,NULL);
INSERT INTO `pedido_detalles` VALUES("9","11","2020-01-25 11:27:27","2020-01-25 11:28:25","8",NULL,"100","100",NULL);



DROP TABLE IF EXISTS `permisos`;

CREATE TABLE `permisos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `motivo` enum('Reposo','Permiso') COLLATE utf8_unicode_ci DEFAULT NULL,
  `cantidad_dias` int(11) NOT NULL,
  `inicio_permiso` date NOT NULL,
  `fin_permiso` date NOT NULL,
  `resta` int(11) NOT NULL,
  `status` enum('En Curso','Cumplido') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'En Curso',
  `id_empleado` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `dias_permiso` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `permisos` VALUES("1","Reposo","3","2019-11-10","2019-11-12","0","Cumplido","3");
INSERT INTO `permisos` VALUES("2","Permiso","3","2019-10-20","2019-10-22","3","Cumplido","3");
INSERT INTO `permisos` VALUES("3","Reposo","4","2019-11-12","2019-11-15","3","En Curso","2");



DROP TABLE IF EXISTS `pre_nomina`;

CREATE TABLE `pre_nomina` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quincena` int(90) NOT NULL,
  `mes` int(90) NOT NULL,
  `anio` int(90) NOT NULL,
  `status` enum('Procesando','Aprobado') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `pre_nomina` VALUES("6","1","11","2019","Aprobado");
INSERT INTO `pre_nomina` VALUES("7","2","11","2019","Aprobado");
INSERT INTO `pre_nomina` VALUES("10","1","12","2019","Aprobado");
INSERT INTO `pre_nomina` VALUES("11","1","3","2021","Procesando");



DROP TABLE IF EXISTS `prenomina_empleado`;

CREATE TABLE `prenomina_empleado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_prenomina` int(11) NOT NULL,
  `id_empleado` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_prenomina` (`id_prenomina`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `prenomina_empleado_ibfk_1` FOREIGN KEY (`id_prenomina`) REFERENCES `pre_nomina` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `prenomina_empleado_ibfk_2` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO `prenomina_empleado` VALUES("14","6","1");
INSERT INTO `prenomina_empleado` VALUES("15","6","2");
INSERT INTO `prenomina_empleado` VALUES("16","6","3");
INSERT INTO `prenomina_empleado` VALUES("17","7","1");
INSERT INTO `prenomina_empleado` VALUES("18","7","2");
INSERT INTO `prenomina_empleado` VALUES("19","7","3");
INSERT INTO `prenomina_empleado` VALUES("28","10","1");
INSERT INTO `prenomina_empleado` VALUES("29","10","2");
INSERT INTO `prenomina_empleado` VALUES("30","10","3");
INSERT INTO `prenomina_empleado` VALUES("31","10","4");
INSERT INTO `prenomina_empleado` VALUES("32","11","1");
INSERT INTO `prenomina_empleado` VALUES("33","11","2");
INSERT INTO `prenomina_empleado` VALUES("34","11","3");
INSERT INTO `prenomina_empleado` VALUES("35","11","4");



DROP TABLE IF EXISTS `privilegios`;

CREATE TABLE `privilegios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `modulo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `privilegio` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `privilegios` VALUES("1","proveedor","registrar");
INSERT INTO `privilegios` VALUES("2","proveedor","listado");
INSERT INTO `privilegios` VALUES("3","proveedor","modificar");
INSERT INTO `privilegios` VALUES("4","proveedor","eliminar");
INSERT INTO `privilegios` VALUES("5","materiaprima","registrar");
INSERT INTO `privilegios` VALUES("6","materiaprima","listado");
INSERT INTO `privilegios` VALUES("7","materiaprima","modificar");
INSERT INTO `privilegios` VALUES("8","materiaprima","eliminar");
INSERT INTO `privilegios` VALUES("9","inventario","registrar");
INSERT INTO `privilegios` VALUES("10","inventario","listado");
INSERT INTO `privilegios` VALUES("11","inventario","modificar");
INSERT INTO `privilegios` VALUES("12","inventario","eliminar");
INSERT INTO `privilegios` VALUES("13","empleado","registrar");
INSERT INTO `privilegios` VALUES("14","empleado","listado");
INSERT INTO `privilegios` VALUES("15","empleado","modificar");
INSERT INTO `privilegios` VALUES("16","empleado","eliminar");
INSERT INTO `privilegios` VALUES("17","asistencia","registrar");
INSERT INTO `privilegios` VALUES("18","asistencia","listado");
INSERT INTO `privilegios` VALUES("19","asistencia","modificar");
INSERT INTO `privilegios` VALUES("20","asistencia","eliminar");
INSERT INTO `privilegios` VALUES("21","asigdeducc","registrar");
INSERT INTO `privilegios` VALUES("22","asigdeducc","listado");
INSERT INTO `privilegios` VALUES("23","asigdeducc","modificar");
INSERT INTO `privilegios` VALUES("24","asigdeducc","eliminar");
INSERT INTO `privilegios` VALUES("25","nomina","registrar");
INSERT INTO `privilegios` VALUES("26","nomina","listado");
INSERT INTO `privilegios` VALUES("27","nomina","modificar");
INSERT INTO `privilegios` VALUES("28","nomina","eliminar");
INSERT INTO `privilegios` VALUES("32","mantenimiento","bitacora");
INSERT INTO `privilegios` VALUES("33","mantenimiento","respaldo");
INSERT INTO `privilegios` VALUES("34","mantenimiento","recuperacion");
INSERT INTO `privilegios` VALUES("35","mantenimiento","listado");



DROP TABLE IF EXISTS `produccion`;

CREATE TABLE `produccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_producto` int(11) NOT NULL,
  `cantidad` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `paletas` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `observacion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `status` enum('Sin Almacenar','Almacenando','Completo') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `productos`;

CREATE TABLE `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `presentacion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `unidad` enum('Kgs','Lts') COLLATE utf8_unicode_ci NOT NULL,
  `stock` int(11) NOT NULL,
  `stock_minimo` int(11) NOT NULL,
  `stock_maximo` int(11) NOT NULL,
  `borrado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `activo` enum('S','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `valor_unitario` int(11) DEFAULT NULL,
  `id_ubicacion` int(11) DEFAULT NULL,
  `id_proveedor` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ubicacion` (`id_ubicacion`),
  KEY `id_proveedor` (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `productos` VALUES("8","CE007","XILENO","BARITANQUE DE 1000 LTS ","Lts","290","100","300","N","S",NULL,NULL,"2");



DROP TABLE IF EXISTS `proveedor`;

CREATE TABLE `proveedor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cod_rif` enum('V','J','E','G') COLLATE utf8_unicode_ci NOT NULL,
  `cedula` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `borrado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `proveedor` VALUES("2","V","25873122","Juan Carlos Figueredo","juan2912@gmail.com","La Victoria","3163502","N");
INSERT INTO `proveedor` VALUES("8","J","099988732","Agropatria C.A","agropatriaca@gmail.com","Cagua Estado Aragua","0244230303","N");
INSERT INTO `proveedor` VALUES("9","J","658493209","Inica Cagua C.A","inicacca@gmail.com","Cagua Estado Aragua","02446548769","N");



DROP TABLE IF EXISTS `recibidos`;

CREATE TABLE `recibidos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pmp` int(11) NOT NULL,
  `cantidad` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `observacion` varchar(90) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ce` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `recibidos` VALUES("2","1","102002","2019-10-07","8jjkk","");



DROP TABLE IF EXISTS `ubicacion`;

CREATE TABLE `ubicacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `bloqueado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `borrado` enum('N','S') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `tipo` enum('I','E') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `ubicacion` VALUES("2","Almacen","N","N","I");



DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `correo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `clave` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_usuario` enum('Admin','Usuario 1','Usuario 2') COLLATE utf8_unicode_ci NOT NULL,
  `pregunta` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `respuesta` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `borrado` enum('S','N') COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `usuarios` VALUES("1","Daileska Vilera","dvilera610@gmail.com","faf393cfff2e1df7ce1dd3906ac0388b74d980f2197b27c9d7c1293e6b3f99cd","Usuario 2","Mascota","Sandy","1_1586365399","N");
INSERT INTO `usuarios` VALUES("2","HÃ©ctor HernÃ¡ndez","hectorher149@gmail.com","67f7fa61d3732d5878756c90c4ba0c3fc4704bf992a3169b1247817f565c8f7a","Admin","nombre de mascota","body","1_1584161024","N");
INSERT INTO `usuarios` VALUES("3","Genessi","genessie@gmail.com","8c4fd8b2c24ffcc223dbf09088bd79734e8404cd4d9e90fc418ecb490622d1ca","Usuario 1","¿Wakanda?","por siempre","admin","S");
